<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200 lao-font">
                    <div class="p-3">
                        <h4 class="text-info"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        </h4>
                        <div class="row">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-4">
                                    <div class="seller-track-info p-2">
                                        <h5><b>ຊື່ລູກຄ້າ:</b> <span class="text-primary"><?php echo e($item->tr_name); ?></span>
                                        </h5>
                                        <h5><b>ເບິໂທ:</b> <span class="text-primary"><?php echo e($item->tr_tel); ?></span></h5>
                                        <h5><b>ລາຍການ:</b> <span
                                                class="text-primary"><?php echo e($item->cus_interest_product); ?></span></h5>
                                        <h5><b>ຫຍີ່ຫໍ້:</b> <span class="text-primary"><?php echo e($item->brand_name); ?></span>
                                        </h5>
                                        <hr>
                                        <button class="btn btn-sm btn-success"
                                            onclick="confirm_contract_customer(<?php echo e($item->id); ?>)"><i
                                                class="fa fa-check-circle-o" aria-hidden="true"></i>
                                            ຢືນຢັນການຕິດຕໍ່</button>

                                    </div>

                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\track-online\resources\views/sellers/previous-tracking.blade.php ENDPATH**/ ?>