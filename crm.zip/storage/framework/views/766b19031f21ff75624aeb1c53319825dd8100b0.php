<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200 lao-font">
                    <div class="p-3">
                        <h4 class="text-info"><i class="fa fa-volume-control-phone" aria-hidden="true"></i>
                            ປະສິດທິພາບການຕິດຕໍ່ຫາລູກຄ້າ</h4>
                        <hr>
                        <div class="row">
                            <div class="col-sm-2">
                                <label class="container mt-2">ເດືອນປີ
                                    <input type="radio" checked="checked" name="radio">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                            <div class="col-sm-2">
                                <div class="input-group mb-3">
                                    <input type="number" class="form-control" aria-label="month"
                                        value="<?php echo e($set_month); ?>" onchange="load_report_bymonth()" id="search-month">
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="input-group mb-3">
                                    <input type="number" class="form-control" aria-label="year"
                                        value="<?php echo e($set_year); ?>" onchange="load_report_bymonth()" id="search-year">
                                </div>
                            </div>

                        </div>
                        <div class="row">
                            <div class="col-sm-2">
                                <label class="container mt-2">ຊ່ວງວັນທີ່
                                    <input type="radio" name="radio">
                                    <span class="checkmark"></span>
                                </label>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-group mb-3">

                                    <input type="date" class="form-control" aria-label="month"
                                        value="<?php echo e(date('Y-m-d')); ?>" id="search-month">
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="input-group mb-3">

                                    <input type="date" class="form-control" aria-label="month"
                                        value="<?php echo e(date('Y-m-d')); ?>" id="search-month">
                                </div>
                            </div>

                        </div>
                        <hr>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="input-group mb-3">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text">ພະນັກງານຂາຍ</span>
                                    </div>
                                    <select name="cb_employee" id="cb_employee" class="form-control">
                                        <option value="all">ທັງໝົດ...</option>
                                        <?php $__currentLoopData = $emp_seller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp_item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($emp_item->id); ?>"><?php echo e($emp_item->emp_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-8">
                                <div class="row">
                                    <div class="col-sm-2">
                                        <label class="container mt-2">ສູງສຸດ
                                            <input type="radio" checked="checked" name="level-radio">
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>
                                    <div class="col-sm-2">
                                        <label class="container mt-2">ຕ່ຳສຸດ
                                            <input type="radio" name="level-radio">
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>
                                    <div class="col-sm-2">
                                        <label class="container mt-2">ສະເລ່ຍ
                                            <input type="radio" name="level-radio">
                                            <span class="checkmark"></span>
                                        </label>
                                    </div>


                                </div>

                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-12">
                                <table class="table table-bordered table-hover">
                                    <tr>
                                        <th>ຊື່ລູກຄ້າ</th>
                                        <th>ລາຍການ</th>
                                        <th>ເວລາບັນທຶກເຂົ້າລະບົບ</th>
                                        <th>ເວລາພະນັກງານຂາຍຕິດຕໍ່ລູກຄ້າ</th>
                                        <th>ເວລາພະນັກງານຂາຍປິດການຂາຍ</th>
                                        <th>ຜູ້ຕິດຕໍ່</th>
                                        <th width="50">ເບິ່ງ</th>
                                    </tr>
                                    <tbody>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $tr_code = $item->tr_code;
                                                $cus_name = $item->tr_name;
                                                $product_name = $item->cus_interest_product;
                                                $tr_date = $item->created_at;
                                                $con_date = '';
                                                $status = $item->status;
                                                $color = '';
                                            ?>
                                            <tr>
                                                <td><?php echo e($cus_name); ?></td>
                                                <td><?php echo e($product_name); ?></td>
                                                <?php if($status == 'ຕິດຕໍ່ສຳເລັດ'): ?>
                                                    
                                                    <?php
                                                        //ຄຳນວນເວລາການຕິດຕໍ່
                                                        $con_cus = App\Models\ContractCustomer::where('tr_code', $tr_code)->get();
                                                        $con_date = $con_cus[0]->created_at;
                                                        //$calculate = $tr_date - $con_date;
                                                        
                                                        $datetime1 = strtotime($tr_date);
                                                        $datetime2 = strtotime($con_date);
                                                        $secs = $datetime2 - $datetime1; // == return sec in difference
                                                        $caculate_con_time = $secs;
                                                        if ($caculate_con_time > 60) {
                                                            $caculate_con_time = $secs / 60;
                                                            $time = 'Minute';
                                                            if ($caculate_con_time > 60) {
                                                                $caculate_con_time = $caculate_con_time / 60;
                                                                $time = 'Hours ';
                                                            }
                                                        } else {
                                                            $time = 'Seconds';
                                                        }
                                                    ?>
                                                    <td><?php echo e($tr_date); ?></td>
                                                    <td><?php echo e($con_date); ?>

                                                        <b>[<?php echo e(number_format($caculate_con_time, 2) . ' ' . $time); ?>]</b>
                                                    </td>

                                                    
                                                    <?php
                                                        $con_cus = App\Models\ContractCustomer::where('tr_code', $tr_code)
                                                            ->orderBy('id', 'DESC')
                                                            ->take(1)
                                                            ->get();
                                                    ?>
                                                    
                                                    <?php if($con_cus[0]->status != 'ລໍຖ້າການຕັດສິນໃຈ'): ?>

                                                        <?php
                                                            $cus_decide = App\Models\CustomerDecides::where('tr_code', $tr_code)->get();
                                                        ?>

                                                        <?php if(count($cus_decide) > 0): ?>
                                                            <?php
                                                                $cus_decide_date = $cus_decide[0]->created_at;
                                                                $datetime1 = strtotime($tr_date);
                                                                $datetime2 = strtotime($cus_decide_date);
                                                                $secs = $datetime2 - $datetime1; // == return sec in difference
                                                                $caculate_decide_time = $secs;
                                                                if ($caculate_decide_time > 60) {
                                                                    $caculate_decide_time = $secs / 60;
                                                                    $time = 'Minute';
                                                                    if ($caculate_decide_time > 60) {
                                                                        $caculate_decide_time = $caculate_decide_time / 60;
                                                                        $time = 'Hours ';
                                                                    }
                                                                } else {
                                                                    $time = 'Seconds';
                                                                }
                                                            ?>
                                                            <td style="color: <?php echo e($color); ?>;">
                                                                <?php echo e($cus_decide_date); ?>

                                                                <b>[<?php echo e(number_format($caculate_decide_time, 2) . ' ' . $time); ?>]</b>
                                                            </td>
                                                        <?php else: ?>
                                                            <td style="color: <?php echo e($color); ?>;">
                                                                <?php echo e($con_cus[0]->status); ?></td>
                                                        <?php endif; ?>
                                                    <?php else: ?>
                                                        
                                                        <td style="color: <?php echo e($color); ?>;">
                                                            <?php echo e($con_cus[0]->status); ?></td>
                                                    <?php endif; ?>

                                                <?php else: ?>
                                                    <td><?php echo e($tr_date); ?> <i class="fa fa-times text-danger"
                                                            aria-hidden="true"></i></td>
                                                    <td><?php echo e($status); ?></td>
                                                    <td><?php echo e($status); ?></td>

                                                <?php endif; ?>
                                                <td><?php echo e($item->emp_name); ?></td>
                                                <td><a href="#" class="text-info"><i class="fa fa-eye"
                                                            aria-hidden="true"></i></a></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                                <span><?php echo e($data->links('vendor.pagination.custom')); ?></span>
                            </div>
                        </div>




                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<script>
    $(document).ready(function(e) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
    });

    function load_report_bymonth() {
        $.blockUI({
            message: ''
        });
        var month = $("#search-month").val();
        var year = $("#search-year").val();
        $.ajax({
            url: "<?php echo e(route('session-set-marketing-report')); ?>",
            type: "GET",
            data: {
                'm': month,
                'y': year
            },
            success: function(e) {
                console.log(e);
                if (e == 'success') {
                    location.reload();
                }
            }
        })
    }
</script>
<?php /**PATH C:\xampp\htdocs\track-online\resources\views/reports/marketing/report-effective.blade.php ENDPATH**/ ?>