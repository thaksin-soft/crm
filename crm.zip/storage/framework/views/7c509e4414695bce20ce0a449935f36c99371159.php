<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>


    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="bg-white border-b border-gray-200 mt-3 lao-font py-8">
                    <h4 class="text-info"><i class="fa fa-pied-piper" aria-hidden="true"></i> ຍີ່ຫໍ້ສິນຄ້າ</h4>

                    <div class="row">
                        <div class="col-md-4">
                            <form method="POST" action="<?php echo e(route('pro-brands.store')); ?>" id="form-brand">
                                <?php echo csrf_field(); ?>
                                
                                <label for="from_base"><span class="text-danger">*</span> ກຸ່ມສິນຄ້າຈາກ
                                    SML</label>

                                <input type="text" name="group_fb_name" id="group_fb_name"
                                    class="text-center form-control" required style="border: aquamarine 1px solid">
                                <div class="input-group mb-3">
                                    <input type="text" name="group_fb_code" id="group_fb_code" class="text-center"
                                        required readonly style="border: aquamarine 1px solid">
                                    <input type="text" class="form-control" name="from_base" id="from_base" readonly
                                        required>
                                    <div class="input-group-prepend">
                                        <span class="input-group-text p-0">
                                            <button class="btn btn-primary m-0" type="button"
                                                data-target="#modal-add-from-base" data-toggle="modal"
                                                onclick="set_add_group_fb('add')"><i class="fa fa-search"
                                                    aria-hidden="true"></i></button>
                                        </span>
                                    </div>
                                </div>
                                <!-- full Name -->
                                <div>
                                    <label for="brand_code"><span class="text-danger">*</span> Code</label>

                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['id' => 'brand_code','class' => 'form-control','type' => 'text','name' => 'brand_code','value' => old('brand_code'),'required' => true,'autofocus' => true,'placeholder' => '...']]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'brand_code','class' => 'form-control','type' => 'text','name' => 'brand_code','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('brand_code')),'required' => true,'autofocus' => true,'placeholder' => '...']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                </div>

                                <!-- full Name -->
                                <div class="mt-4">
                                    <label for="brand_name"><span class="text-danger">*</span>
                                        ຊື່ຍີ່ຫໍ້ສິນຄ້າ</label>

                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['id' => 'brand_name','class' => 'form-control','type' => 'text','name' => 'brand_name','value' => old('brand_name'),'required' => true,'autofocus' => true,'placeholder' => '...']]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['id' => 'brand_name','class' => 'form-control','type' => 'text','name' => 'brand_name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('brand_name')),'required' => true,'autofocus' => true,'placeholder' => '...']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                </div>

                                <div class="flex items-center justify-end mt-4">


                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'btn btn-success']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'btn btn-success']); ?><i class="fa fa-floppy-o" aria-hidden="true"></i>
                                        <?php echo e(__(' ບັນທຶກ')); ?>

                                     <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                                </div>
                            </form>
                        </div>
                        <div class="col-md-8">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                        <th>ລຳດັບ</th>
                                        <th>Code (sml)</th>
                                        <th>Code</th>
                                        <th>ຊື່ຍີ່ຫໍ້ສິນຄ້າ</th>
                                        <th width="30">ແກ້ໄຂ</th>
                                        <th width="30">ລຶບ</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->id); ?></td>
                                            <td><?php echo e($item->code_fb); ?></td>
                                            <td><?php echo e($item->code); ?></td>
                                            <td><?php echo e($item->brand_name); ?></td>
                                            <td class="text-center">
                                                <a href="#" class="text-warning" data-toggle="modal"
                                                    data-target="#modal-edit-emp"
                                                    onclick="set_edit_brand(<?php echo e($item->id); ?>, '<?php echo e($item->code); ?>', 
                                                    '<?php echo e($item->brand_name); ?>', '<?php echo e($item->code_fb); ?>', '<?php echo e($item->from_base); ?>')"><i
                                                        class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                            </td>
                                            <td class="text-center">
                                                <a href="#" class="text-danger"
                                                    onclick="delete_brands(<?php echo e($item->id); ?>)"><i
                                                        class="fa fa-trash" aria-hidden="true"></i></a>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div>
                    </div>


                </div>
            </div>
        </div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="modal-edit-emp">
        <div class="modal-dialog">
            <div class="modal-content">

                <!-- Modal Header -->
                <div class="modal-header lao-font">
                    <h4 class="modal-title"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> ແກ້ໄຂຂໍ້ມູນ</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body lao-font">
                    <form method="POST" action="" id="form-edit-brand">
                        <?php echo csrf_field(); ?>
                        
                        <label for="from_base"><span class="text-danger">*</span> ກຸ່ມສິນຄ້າຈາກ
                            SML</label>

                        <input type="text" name="group_fb_name" id="group_fb_name" class="text-center form-control"
                            required readonly style="border: aquamarine 1px solid">
                        <div class="input-group mb-3">
                            <input type="text" name="group_fb_code" id="group_fb_code" class="text-center" required
                                readonly style="border: aquamarine 1px solid">
                            <input type="text" class="form-control" name="from_base" id="from_base" readonly required>
                            <div class="input-group-prepend">
                                <span class="input-group-text p-0">
                                    <button class="btn btn-primary m-0" type="button" data-target="#modal-add-from-base"
                                        data-toggle="modal" onclick="set_add_group_fb('edit')"><i class="fa fa-search"
                                            aria-hidden="true"></i></button>
                                </span>
                            </div>
                        </div>
                        <input type="hidden" name="brand_id">
                        <!-- full Name -->
                        <div>
                            <label for="edit_code"><span class="text-danger">*</span> Code</label>

                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['class' => 'form-control','type' => 'text','name' => 'edit_code','value' => old('edit_code'),'required' => true,'autofocus' => true,'placeholder' => '...']]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'form-control','type' => 'text','name' => 'edit_code','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('edit_code')),'required' => true,'autofocus' => true,'placeholder' => '...']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </div>

                        <div class="mt-4">
                            <label for="edit_brand_name"><span class="text-danger">*</span> ຊື່ຍີ່ຫໍ້ສິນຄ້າ</label>

                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.input','data' => ['class' => 'form-control','type' => 'text','name' => 'edit_brand_name','value' => old('edit_brand_name'),'required' => true,'autofocus' => true,'placeholder' => '...']]); ?>
<?php $component->withName('input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'form-control','type' => 'text','name' => 'edit_brand_name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('edit_brand_name')),'required' => true,'autofocus' => true,'placeholder' => '...']); ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </div>


                        <div class="flex items-center justify-end mt-4">


                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.button','data' => ['class' => 'btn btn-success']]); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'btn btn-success']); ?><i class="fa fa-floppy-o" aria-hidden="true"></i>
                                <?php echo e(__(' ບັນທຶກ')); ?>

                             <?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
                        </div>
                    </form>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal" id="close-edit">Close</button>
                </div>

            </div>
        </div>
    </div>
    <!-- The Modal -->
    <div class="modal" id="modal-add-from-base">
        <div class="modal-dialog">
            <div class="modal-content lao-font">

                <!-- Modal Header -->
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>

                <!-- Modal body -->
                <div class="modal-body">
                    <input type="hidden" id="add-states">
                    <div class="tab">
                        <button class="tablinks active" onclick="load_group_from_base(event, 'odien')">Odien</button>
                        <button class="tablinks" onclick="load_group_from_base(event, 'p&p')">P&P</button>
                    </div>

                    <div id="odien" class="tabcontent" style="display: block">
                        <h3>Odien</h3>
                        <table class="table">
                            <tr>
                                <th></th>
                                <th>Code</th>
                                <th>ຊື່ກຸ່ມສິນຄ້າ</th>
                            </tr>
                            <tbody id="fb-odien-table">

                            </tbody>
                        </table>
                    </div>

                    <div id="p&p" class="tabcontent">
                        <h3>P&P</h3>
                        <table class="table">
                            <tr>
                                <th></th>
                                <th>Code</th>
                                <th>ຊື່ກຸ່ມສິນຄ້າ</th>
                            </tr>
                            <tbody id="fb-pp-table"></tbody>
                        </table>
                    </div>
                </div>

                <!-- Modal footer -->
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>

            </div>
        </div>
    </div>

 <?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>


<script>
    function set_add_group_fb(states) {
        $("#add-states").val(states);
    }
    load_fb_pp();

    function load_fb_pp() {
        $.ajax({
            type: "GET",
            url: "<?php echo e(Route('fetch-brand-fb-pp')); ?>",
            success: function(e) {

                $("#fb-pp-table").html('');
                $.each(e, function(i, item) {
                    let base = 'p&p';
                    let code = item.code;
                    let name = item.name_1;
                    for (let i = 0; i < name.length; i++) {
                        name = name.replace('"', '');
                    }

                    $("#fb-pp-table").append(`<tr>
                    <td><button class="btn btn-sm btn-outline-success" 
                    data-dismiss="modal" onclick="get_brand_fb('${code}','${name}','${base}')">
                    <i class="fa fa-check-circle-o" aria-hidden="true">
                    </i></button></td>
                    <td>${item.code}</td>
                    <td>${name}</td></tr>`);

                })
            }
        })

    }
    load_fb_odien();

    function load_fb_odien() {
        $.ajax({
            type: "GET",
            url: "<?php echo e(Route('fetch-brand-fb-odien')); ?>",
            success: function(e) {
                //console.log(e);
                $("#fb-odien-table").html('');
                $.each(e, function(i, item) {
                    let base = 'odien';
                    let code = item.code;
                    let name = item.name_1;
                    for (let i = 0; i < name.length; i++) {
                        name = name.replace('"', '');
                    }

                    $("#fb-odien-table").append(`<tr>
                    <td><button class="btn btn-sm btn-outline-success" 
                    data-dismiss="modal" onclick="get_brand_fb('${code}','${name}','${base}')">
                    <i class="fa fa-check-circle-o" aria-hidden="true">
                    </i></button></td>
                    <td>${item.code}</td>
                    <td>${name}</td></tr>`);
                })
            }
        })

    }

    function get_brand_fb(code, name, base) {
        let states = $("#add-states").val();
        if (states == 'add') {
            $("#form-brand input[name='from_base']").val(base);
            $("#form-brand input[name='group_fb_code']").val(code);
            $("#form-brand input[name='group_fb_name']").val(name);
        } else {
            $("#form-edit-brand input[name='from_base']").val(base);
            $("#form-edit-brand input[name='group_fb_code']").val(code);
            $("#form-edit-brand input[name='group_fb_name']").val(name);
        }

    }

    function load_group_from_base(evt, fbName) {
        var i, tabcontent, tablinks;
        tabcontent = document.getElementsByClassName("tabcontent");
        for (i = 0; i < tabcontent.length; i++) {
            tabcontent[i].style.display = "none";
        }
        tablinks = document.getElementsByClassName("tablinks");
        for (i = 0; i < tablinks.length; i++) {
            tablinks[i].className = tablinks[i].className.replace(" active", "");
        }
        document.getElementById(fbName).style.display = "block";
        evt.currentTarget.className += " active";

    }
    $(document).ready(function(e) {
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });
        $('#form-edit-brand').submit(function(e) {
            e.preventDefault();
            $('#close-edit').click();
            var id = $('#form-edit-brand input[name="brand_id"]').val();
            var url = "pro-brands/" + id;
            $.blockUI({
                message: 'ກຳລັງແກ້ໄຂ'
            });
            $.ajax({
                url: url,
                type: 'PUT',
                data: $(this).serialize(),
                success: function(e) {
                    $.unblockUI();
                    console.log(e);
                    if (e == 'success') {
                        location.reload();
                    }
                }
            });
        });
    });

    function set_edit_brand(id, code, brand_name, code_fb, from_base) {
        $("#form-edit-brand input[name='from_base']").val(from_base);
        $("#form-edit-brand input[name='group_fb_code']").val(code_fb);
        $("#form-edit-brand input[name='group_fb_name']").val('');
        //
        $('#form-edit-brand input[name="brand_id"]').val(id);
        $('#form-edit-brand input[name="edit_code"]').val(code);
        $('#form-edit-brand input[name="edit_brand_name"]').val(brand_name);
    }

    function delete_brands(id) {
        Swal.fire({
            title: '<span class="lao-font">ຢືນຢັນການລຶບຂໍ້ມູນ </span>?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: '<span class="lao-font">ຢືນຢັນ</span>'
        }).then((result) => {
            var url = 'pro-brands/' + id;
            var token = $("meta[name='csrf-token']").attr("content");
            if (result.isConfirmed) {
                $.ajax({
                    url: url,
                    type: 'DELETE',
                    data: {
                        _token: token,
                        id: id
                    },
                    success: function(e) {
                        console.log(e);
                        if (e == 'success') {
                            location.reload();
                        }
                    }
                })
            }
        })
    }
</script>
<?php /**PATH C:\xampp\htdocs\track-online\resources\views/brands/index.blade.php ENDPATH**/ ?>