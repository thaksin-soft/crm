<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
    <div class="menu_section">
        <ul class="nav side-menu">
            <li class="model-item"><a href="/"><i class="fa fa-home"></i> Dashboard</a></li>

            

            
        </ul>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\track-online\resources\views/layouts/marketing-sidebar.blade.php ENDPATH**/ ?>